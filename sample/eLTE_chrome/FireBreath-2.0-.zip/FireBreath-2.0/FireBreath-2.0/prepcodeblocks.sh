#!/bin/bash -e

GEN='CodeBlocks - Unix Makefiles'

source ${0%/*}/prepmake.sh "$@"
