FireBreath 2.0
==============

Home page: [http://www.firebreath.org/display/fb2](http://www.firebreath.org/display/fb2)

FireBreath is a cross-platform browser plugin framework. It supports ActiveX and NPAPI on Windows, Mac OS X, and Linux (probably other unix-derivitives as well).

Version 2.0 introduces a major string of refactors which makes all interaction between the web page and the plugin asynchronous.  This allows us to add support for Native Messaging.

Getting the source
==================

FireBreath relies on one or more submodules; make sure you get them!
