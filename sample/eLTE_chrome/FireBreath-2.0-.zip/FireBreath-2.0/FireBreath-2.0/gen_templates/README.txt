These files are generated from your PluginConfig.cmake file. Do not modify them directly!
Your changes will be lost the next time you run a prep script!

If you need to customize any of these files beyond the norm, you may copy the file in
question from ${FB_ROOT}/gen_templates/ to ${FB_CURRENT_PLUGIN_DIR} and
re-run the prep script; FireBreath's cmake files will automatically use
your version. Please note that this is not supported and may cause
problems when the default template files change!
