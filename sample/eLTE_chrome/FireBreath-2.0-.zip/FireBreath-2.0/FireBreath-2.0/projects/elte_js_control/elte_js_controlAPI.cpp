/**********************************************************\

  Auto-generated elte_js_controlAPI.cpp

\**********************************************************/

#include "elte_js_controlAPI.h"

///////////////////////////////////////////////////////////////////////////////
/// @fn FB::variant elte_js_controlAPI::echo(const FB::variant& msg)
///
/// @brief  Echos whatever is passed from Javascript.
///         Go ahead and change it. See what happens!
///////////////////////////////////////////////////////////////////////////////
FB::variant elte_js_controlAPI::echo(const FB::variant& msg)
{
    static int n(0);
    fire_echo("So far, you clicked this many times: ", n++);

    // return "foobar";
    return msg;
}

///////////////////////////////////////////////////////////////////////////////
/// @fn FB::variant elte_js_controlAPI::echo(const FB::variant& msg)
///
/// @brief  Echos whatever is passed from Javascript but asynchronously;
///         This is a great example of how async resolution works
///////////////////////////////////////////////////////////////////////////////
FB::variantPromise elte_js_controlAPI::echoSlowly(const FB::variant& a)
{
    FB::variantDeferred dfd;

    auto callback = [dfd, a]() {
        std::this_thread::sleep_for(std::chrono::seconds(2));
        dfd.resolve(a);
    };

    std::async(callback);

    return dfd.promise();
}


///////////////////////////////////////////////////////////////////////////////
/// @fn elte_js_controlPtr elte_js_controlAPI::getPlugin()
///
/// @brief  Gets a reference to the plugin that was passed in when the object
///         was created.  If the plugin has already been released then this
///         will throw a FB::script_error that will be translated into a
///         javascript exception in the page.
///////////////////////////////////////////////////////////////////////////////
elte_js_controlPtr elte_js_controlAPI::getPlugin()
{
    elte_js_controlPtr plugin(m_plugin.lock());
    if (!plugin) {
        throw FB::script_error("The plugin is invalid");
    }
    return plugin;
}

// Read/Write property testString
std::string elte_js_controlAPI::get_testString()
{
    return m_testString;
}

void elte_js_controlAPI::set_testString(const std::string& val)
{
    m_testString = val;
}

// Read-only property version
std::string elte_js_controlAPI::get_version()
{
    return FBSTRING_PLUGIN_VERSION;
}

void elte_js_controlAPI::testEvent()
{
    fire_test();
}

ELTE_INT32 elte_js_controlAPI::FBElteSdkInit(ELTE_INT32 iMediaBypass)
{
	ELTE_INT32 iRet = ELTE_SDK_Init(iMediaBypass);

	if (0 == iRet)
	{
		iRet = ELTE_SDK_SetEventCallBack(ELTE_EventCallBack, this);
	}

	return iRet;
}

ELTE_INT32 elte_js_controlAPI::FBElteSdkLogin(const std::string& strUserID, const std::string& strPWD, const std::string& strServerIP, const std::string& strLocalIP, const ELTE_UINT32& uiServerSIPPort)
{
	ELTE_INT32 iRet = ELTE_SDK_Login(strUserID.c_str(), strPWD.c_str(), strServerIP.c_str(), strLocalIP.c_str(), uiServerSIPPort);
	return iRet;
}

std::string elte_js_controlAPI::FBElteSdkGetDcUsers(const std::string& strUserID)
{
	ELTE_CHAR* pDcUsers = NULL;
	ELTE_INT32 iRet = ELTE_SDK_GetDcUsers(strUserID.c_str(), &pDcUsers);
	std::string strTemp;
	if (0 != iRet)
	{
		strTemp.append("<Content>");
		strTemp.append("<ResultCode>");
		strTemp.append(Int2String(iRet));
		strTemp.append("</ResultCode>");
		strTemp.append("</Content>");
		return strTemp;
	}

	strTemp = pDcUsers;
	iRet = ELTE_SDK_ReleaseBuffer(pDcUsers);
	return strTemp;
}

std::string elte_js_controlAPI::Int2String(ELTE_INT32 iVar)
{
	ELTE_CHAR buf[20] = { 0 };
	(ELTE_VOID)_itoa_s(iVar, buf, 10);
	return std::string(buf);
}

ELTE_VOID __SDK_CALL elte_js_controlAPI::ELTE_EventCallBack(ELTE_INT32 iEventType, ELTE_VOID* pEventBuf, ELTE_UINT32 uiBufSize, ELTE_VOID* pUserData)
{
	if (NULL == pEventBuf && 4 != iEventType)//EVENT_NOTIFY_PROVISION_ALLRESYNC
	{
		return;
	}

	elte_js_controlAPI* pThis = (elte_js_controlAPI*)pUserData;

	if (4 == iEventType)
	{
		pThis->m_callback->InvokeAsync("", FB::VariantList{ iEventType, "" });
	}
	else
	{
		std::string strTemp = (ELTE_CHAR*)pEventBuf;
		pThis->m_callback->InvokeAsync("", FB::VariantList{ iEventType, strTemp });
	}
}

ELTE_VOID elte_js_controlAPI::FBElteSdkSetCallBack(const FB::JSObjectPtr& callback)
{
	m_callback = callback;
}