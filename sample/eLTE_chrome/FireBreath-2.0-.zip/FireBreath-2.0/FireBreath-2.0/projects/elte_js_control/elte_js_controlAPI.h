/**********************************************************\

  Auto-generated elte_js_controlAPI.h

\**********************************************************/

#include <string>
#include <sstream>
#include "JSAPIAuto.h"
#include "BrowserHost.h"
#include "elte_js_control.h"
#include "eLTE_SDK.h"
#include "eLTE_Types.h"
#include "JSObject.h"
#include <future>
#include "global/config.h"

#ifndef H_elte_js_controlAPI
#define H_elte_js_controlAPI

// This macro defines elte_js_controlAPIPtr, elte_js_controlAPIWeakPtr,
// elte_js_controlAPIConstPtr, and elte_js_controlAPIWeakConstPtr
FB_FORWARD_PTR(elte_js_controlAPI);

class elte_js_controlAPI : public FB::JSAPIAuto
{
public:
    ////////////////////////////////////////////////////////////////////////////
    /// @fn elte_js_controlAPI::elte_js_controlAPI(const elte_js_controlPtr& plugin, const FB::BrowserHostPtr host)
    ///
    /// @brief  Constructor for your JSAPI object.
    ///         You should register your methods, properties, and events
    ///         that should be accessible to Javascript from here.
    ///
    /// @see FB::JSAPIAuto::registerMethod
    /// @see FB::JSAPIAuto::registerProperty
    /// @see FB::JSAPIAuto::registerEvent
    ////////////////////////////////////////////////////////////////////////////
    elte_js_controlAPI(const elte_js_controlPtr& plugin, const FB::BrowserHostPtr& host) :
        m_plugin(plugin), m_host(host)
    {
        registerMethod("echo",      make_method(this, &elte_js_controlAPI::echo));
        registerMethod("echoSlowly",make_method(this, &elte_js_controlAPI::echoSlowly));
        registerMethod("testEvent", make_method(this, &elte_js_controlAPI::testEvent));

        // Read-write property
        registerProperty("testString",
                         make_property(this,
                                       &elte_js_controlAPI::get_testString,
                                       &elte_js_controlAPI::set_testString));

        // Read-only property
        registerProperty("version",
                         make_property(this,
                                       &elte_js_controlAPI::get_version));

		registerMethod("FBElteSdkInit", make_method(this, &elte_js_controlAPI::FBElteSdkInit));//��ʼ��	
		registerMethod("FBElteSdkLogin", make_method(this, &elte_js_controlAPI::FBElteSdkLogin));//login	
		registerMethod("FBElteSdkGetDcUsers", make_method(this, &elte_js_controlAPI::FBElteSdkGetDcUsers));//��ȡ����̨�û�	

		registerMethod("FBElteSdkSetCallBack", make_method(this, &elte_js_controlAPI::FBElteSdkSetCallBack));//���ûص�����
    }

    ///////////////////////////////////////////////////////////////////////////////
    /// @fn elte_js_controlAPI::~elte_js_controlAPI()
    ///
    /// @brief  Destructor.  Remember that this object will not be released until
    ///         the browser is done with it; this will almost definitely be after
    ///         the plugin is released.
    ///////////////////////////////////////////////////////////////////////////////
    virtual ~elte_js_controlAPI() {};

    elte_js_controlPtr getPlugin();

    // Read/Write property ${PROPERTY.ident}
    std::string get_testString();
    void set_testString(const std::string& val);

    // Read-only property ${PROPERTY.ident}
    std::string get_version();

    // Method echo
    FB::variant echo(const FB::variant& msg);
    // Method echo slowly (async echo)
    FB::variantPromise echoSlowly(const FB::variant& a);

    // Event helpers
    FB_JSAPI_EVENT(test, 0, ());
    FB_JSAPI_EVENT(echo, 2, (const FB::variant&, const int));

    // Method test-event
    void testEvent();

	ELTE_INT32 FBElteSdkInit(ELTE_INT32 iMediaBypass);
	ELTE_INT32 FBElteSdkLogin(const std::string& strUserID, const std::string& strPWD, const std::string& strServerIP, const std::string& strLocalIP, const ELTE_UINT32& uiServerSIPPort);
	std::string FBElteSdkGetDcUsers(const std::string& strUserID);

	ELTE_VOID FBElteSdkSetCallBack(const FB::JSObjectPtr& callback);


	// �¼��ص�����
	static ELTE_VOID __SDK_CALL ELTE_EventCallBack(ELTE_INT32 iEventType, ELTE_VOID* pEventBuf, ELTE_UINT32 uiBufSize, ELTE_VOID* pUserData);
private:
	std::string Int2String(ELTE_INT32 iVar);

private:
    elte_js_controlWeakPtr m_plugin;
    FB::BrowserHostPtr m_host;

    std::string m_testString;
public:
	FB::JSObjectPtr m_callback;  ///�����ص�////
};

#endif // H_elte_js_controlAPI

