#include <Windows.h>
#include "vlc/vlc.h"

int main(int argc, char **argv)
{
	libvlc_instance_t * inst;
	inst = libvlc_new (0, NULL);

	//������һ·
	libvlc_media_player_t *mp1;
	libvlc_media_t *m1;

	m1 = libvlc_media_new_location(inst, "file:///D:\\test.sdp");

	const char *options1[] = {
		":no-audio",
		":sout=#transcode{vcodec=theo,vb=1600,acodec=none}:http{mux=ogg,dst=:8080/xxzy}",
		":network-caching=300"
	};

	for (int i = 0; i < sizeof(options1) / sizeof(options1[0]); i++)
	{
		libvlc_media_add_option (m1, options1[i]);
	}
	mp1 = libvlc_media_player_new_from_media (m1);
	libvlc_media_release (m1);
	libvlc_media_player_play (mp1);


	////�����ڶ�·
	//libvlc_media_player_t *mp2;
	//libvlc_media_t *m2;

	//m2 = libvlc_media_new_location(inst, "file:///D:\\test1.sdp");

	//const char *options2[] = {
	//	":no-audio",
	//	":sout=#transcode{vcodec=theo,vb=2048,acodec=none}:http{mux=ogg,dst=:8080/xxzy1}",
	//	":network-caching=100"
	//};

	//for (int i = 0; i < sizeof(options2) / sizeof(options2[0]); i++)
	//{
	//	libvlc_media_add_option (m2, options2[i]);
	//}
	//mp2 = libvlc_media_player_new_from_media (m2);
	//libvlc_media_release (m2);
	//libvlc_media_player_play (mp2);


	while(true)
	{
		;
	}
	return 0;
}